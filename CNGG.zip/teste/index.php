<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>CNGG</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/js/bootstrap.js">
    <link rel="stylesheet" href="assets/css/main.css">
  </head>
  <body>


    <?php
    include "security/database/connection.php";
    ?>


    <?php
      $sql = "SELECT id,imagem FROM filmes WHERE id=:id";
      $stm_sql = $db_connection->prepare($sql);
      $stm_sql->execute();
      $filmes_id = $stm_sql->fetchAll(PDO::FETCH_ASSOC);


      $sql = "SELECT imagem FROM filmes WHERE id=:id";
      $stm_sql = $db_connection->prepare($sql);
      $stm_sql -> bindParam(':id',$id);
      $stm_sql -> execute();
      $filmes_imagem = $stm_sql -> fetch(PDO::FETCH_ASSOC);


    ?>


    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a>
        <img src="assets/images/CNGG2.png" alt="." style="height: 40px ; width: 90px">
      </a>
      <a class="navbar-brand">Cinema Nacional Geek Gamer</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
          <a class="nav-link" href="app/controle.php">
          <?php
          session_start();
          if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
            echo "";
            $_SESSION['email'] = "";
          }else{
            if ($_SESSION['email'] == "2@2"){
                echo "Registro Geral";
            }else{
              echo "";
            }
          }
          ?>
          </a>
          </li>
          <li class="nav-item">
        </ul>
        <ul class="navbar-nav ml-md-auto">
          <li class="nav-item">
            <a href="security/authentication/logout.php">
              <?php
              if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
                echo "";
              }else{
                echo "Sair";
              }
              ?>
            </a>
          </li>
          <li class="nav-item">
            <a href="app/entrar.php">
              <?php
              if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
                echo "Entrar";
              }else{
                echo "";
              }
              ?>
            </a>
          </li>
          <li class="nav-item">
            <a><img src="assets/images/cinza.png"></a>
          </li>
          <li class="nav-item">
            <a href="app/cadastro.php">
              <?php
              if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
                echo "Cadastro";
              }else{
                echo "";
              }
              ?>
            </a>
          </li>
        </ul>
      </div>
    </nav>


    <div class="container-fluid mt-5">
      <a href="app/main.php?id=<?php echo 1;?>&imagem=Chappie.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/Chappie.jpg" id="poster1"></a>
      <a href="app/main.php?id=<?php echo 2;?>&imagem=alita.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/alita.jpg" id="poster2"></a>
      <a href="app/main.php?id=<?php echo 3;?>&imagem=pacificrim.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/pacificrim.jpg" id="poster3"></a>
      <a href="app/main.php?id=<?php echo 4;?>&imagem=tron.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/tron.jpg" id="poster4"></a>
      <a href="app/main.php?id=<?php echo 5;?>&imagem=Real_Steel.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/Real_Steel.jpg" id="poster5"></a>
      <a href="app/main.php?id=<?php echo 6;?>&imagem=number1.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/number1.jpg" id="poster6"></a>
      <a href="app/main.php?id=<?php echo 7;?>&imagem=Avatar.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/Avatar.jpg" id="poster7"></a>
      <a href="app/main.php?id=<?php echo 8;?>&imagem=jumanji.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/jumanji.jpg" id="poster8"></a>
      <a href="app/main.php?id=<?php echo 9;?>&imagem=avengers.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/avengers.jpg" id="poster9"></a>
      <a href="app/main.php?id=<?php echo 10;?>&imagem=lionkingfolder.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/lionkingfolder.jpg" id="poster10"></a>
      <a href="app/main.php?id=<?php echo 11;?>&imagem=shazam.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/shazam.jpg" id="poster11"></a>
      <a href="app/main.php?id=<?php echo 12;?>&imagem=fantasmas.jpg&email=<?php echo $_SESSION['email'];?>"><img src="assets/images/fantasmas.jpg" id="poster12"></a>


      <div class="row">
        <div class="col-12">
          <?php if(isset($_GET['mensagem']) && isset($_GET['status'])) { ?>
          <div class="alert alert-<?php echo $_GET['status']; ?> alert-dismissible show" role="alert">
            <?php echo $_GET['mensagem']; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <?php } ?>
        </div>
      </div>


    </div>
  </body>
</html>
