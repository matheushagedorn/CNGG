<?php
  $email                = $_POST['email'];
  $senha                = $_POST['senha'];
  $permissao            = $_POST['permissao'];
  $senha_criptografada  = md5($senha);
  $msg                  = "";
  $link                 ="../../app/entrar.php?";
  $status               ="danger";


  if($email==""){
    $msg ="Preencha o campo email";
  }elseif($senha==""){
    $msg ="Preencha o campo senha";
  }else{
    include "../database/connection.php";

    $sql = "SELECT * FROM usuarios WHERE email=:email AND senha=:senha";
    $stm_sql = $db_connection->prepare($sql);
    $stm_sql->bindParam(':email', $email);
    $stm_sql->bindParam(':senha', $senha_criptografada);
    $stm_sql->execute();



    if($stm_sql->rowCount()==1){
      session_start();
      $_SESSION['email'] = $email;
      $_SESSION['senha'] = $senha_criptografada;
      $_SESSION['permissao'] = $permissao;
      $_SESSION['idsessao'] = session_id();
      $link = "../../index.php?";

      $msg = "Login efetuado com sucesso!";
      $status = "success";
    }else{

      $msg = "Usuário ou senha incorreto!";
      $status = "danger";
    }

  }

header("Location: ".$link . "&mensagem=".$msg . "&status=".$status."&sessao=". $_SESSION['email']);
?>
