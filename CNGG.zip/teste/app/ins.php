<?php
  $nome                 = $_POST['nome'];
  $email                = $_POST['email'];
  $senha                = $_POST['senha'];
  $senha_criptografada  = md5($senha);
  $msg                  = "";
  $link                 = "cadastro.php?";
  $status               = "danger";


  if($nome==""){
    $msg = "Preencha o campo nome";
  }elseif($email==""){
    $msg ="Preencha o campo email";
  }elseif($senha==""){
    $msg ="Preencha o campo senha";
  }else{
    include "../security/database/connection.php";

    $sql = "SELECT * FROM usuarios WHERE nome=:nome";
    $stm_sql = $db_connection->prepare($sql);
    $stm_sql->bindParam(':nome', $nome);
    $stm_sql->execute();

    if($stm_sql->rowCount()==0){
      $sql = "INSERT INTO usuarios (id,nome,senha,email,permissao) VALUES (:id,:nome,:senha,:email,:permissao)";
      $stm_sql = $db_connection->prepare($sql);
      $id = null;
      $permissao = "1";
      $stm_sql->bindParam(':id', $id);
      $stm_sql->bindParam(':nome', $nome);
      $stm_sql->bindParam(':senha', $senha_criptografada);
      $stm_sql->bindParam(':email', $email);
      $stm_sql->bindParam(':permissao', $permissao);
      $result = $stm_sql->execute();
      if($result){
        $msg = "Cadastro efetuado com sucesso! Você já pode apertar na seta para voltar ao catálogo.";
        $status = "success";
      }else{
        $msg = "Falha ao cadastrar!";
        $status = "danger";
      }
    }else{
      $msg = "Esse usuário já está cadastrado no banco de dados.";
      $status = "warning";
    }
  }
  header("Location: ".$link . "&mensagem=".$msg . "&status=".$status );
?>
