<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>Informações</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/js/bootstrap.js">
    <link rel="stylesheet" href="../assets/css/main.css">
  </head>
  <body class="fundoinfoposter">


    <?php
      include "../security/database/connection.php";
    ?>


    <?php
      $email=$_GET['email'];
      $id = $_GET['id'];
      $imagem = $_GET['imagem'];
      $varimg= "../assets/images/".$imagem;

      $sql = "SELECT id, nome, sinopse, avaliacao, lancamento, classificacao FROM filmes WHERE id=:id";
      $stm_sql = $db_connection->prepare($sql);
      $stm_sql -> bindParam(':id',$id);
      $stm_sql -> execute();
      $filmes = $stm_sql -> fetch(PDO::FETCH_ASSOC);
    ?>


    <div id="quadradoopaco"></div>
    <img src=<?php echo $varimg; ?> class="infoposter">
    <form class="forminfoposter" action="compra.php?fil=<?php echo $filmes['id'];?>&email=<?php echo $email;?>" method="post">
      <label class="Nomeinfoposter">Nome:</label>
      <h3 class="h3nomeinfoposter"><?php echo $filmes['nome'];?></h3>
      <br>
      <label class="Sinopseinfoposter">Sinopse:</label>
      <h3 class="h3sinopseinfoposter"><?php echo $filmes['sinopse'];?></h3>
      <br>
      <label class="Avaliacaoinfoposter">Avaliação:</label>
      <h3 class="h3avaliacaoinfoposter"><?php echo $filmes['avaliacao'];?></h3>
      <br>
      <label class="Datainfoposter">Data de Lançamento:</label>
      <h3 class="h3datainfoposter"><?php echo $filmes['lancamento'];?></h3>
      <br>
      <label class="clasificacaoinfoposter">Clasificação:</label>
      <h3 class="h3clasificacaoinfoposter"><?php echo $filmes['classificacao'];?></h3>
      <br>
      <button type="button" class="btn btn-success btninfoposter" name="button" data-toggle="modal" data-target="#staticBackdrop" >Comprar Ingresso</button>
      <a href="../index.php" type="button" class="ainfoposter" name="button"><img src="../assets/images/seta.png" alt="." style="height: 70px ; width: 70px"></a>


      <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel"></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="row col-6">
              <h5>Forma de pagamento<h5>
                <select name="pagamento">
                  <option value="">Selecione</option>
                  <option value="cartao">cartão de crédito</option>
                  <option value="paypal">paypal</option>
                  <option value="boleto">boleto</option>
                </select>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">não</button>
              <button type="submit" name="button" class="btn btn-primary">sim</button>
            </div>
          </div>
        </div>
      </div>


    </form>
  </body>
</html>
