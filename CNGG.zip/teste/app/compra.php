<?php
  session_start();
  if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
    header("Location: http://localhost/teste/security/authentication/login.php");
    exit;
  }else{
  $pagamento=$_POST['pagamento'];
  $filmes_id=$_GET['fil'];
  $usuarios_id=$_GET['email'];
  $link="../index.php?";
  $status="danger";
  $msg="";



    if ($pagamento="") {
      $msg="Insira uma forma de pagamento.";
    }else{

      include "../security/database/connection.php";
      $sql = "SELECT * FROM usuarios WHERE email=:email";
      $stm_sql = $db_connection->prepare($sql);
      $stm_sql->bindParam(':email',$email);
      $stm_sql->execute();
      $users = $stm_sql->fetchAll(PDO::FETCH_ASSOC);


      $sql = "INSERT INTO ingressos (id,usuarios_id,filmes_id) VALUES (:id,:usuarios_id,:filmes_id)";
      $stm_sql =$db_connection->prepare($sql);
      $id = null;
      $stm_sql->bindParam(':id',$id);
      $stm_sql->bindParam(':usuarios_id',$usuarios_id);
      $stm_sql->bindParam(':filmes_id',$filmes_id);
      $result = $stm_sql->execute();

      if($result){
        $msg = "Produto cadastrado com sucesso!";
        $status="success";
      }else{
        $msg = "Falha ao cadastrar o produto";
      }
    }
    header("location: ". $link  . "&mensagem=". $msg. "&status=" . $status);
  }
?>
