<?php

  session_start();
  if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
    header("Location:  http://localhost/teste/security/authentication/login.php");
    exit;
  }

  include "../security/database/connection.php";

  $id = $_GET['id'];
  $link = "controle.php?";
  $sql = "DELETE FROM usuarios WHERE id=:id";
  $stm_sql = $db_connection->prepare($sql);
  $stm_sql->bindParam(":id", $id);
  $result = $stm_sql->execute();

  if ($result) {
    $msg = "Usuário excluído com sucesso.";
    $status = "success";
  }else{
    $msg = "Erro ao excluir.";
    $status = "danger";
  }
    header("Location: ".$link . "&mensagem=".$msg . "&status=".$status );
?>
