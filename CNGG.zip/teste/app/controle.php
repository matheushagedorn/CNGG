<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>CNGG</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/js/bootstrap.js">
    <link rel="stylesheet" href="../assets/js/main.js">
    <link rel="stylesheet" href="../assets/css/main.css">
  </head>
  <body>
    <?php
      session_start();
      if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
        header("Location:  http://localhost/teste/security/authentication/login.php");
        exit;
      }
    ?>


    <?php
      include "../security/database/connection.php";
    ?>


    <div class="row">
      <div class="col-12">
        <?php if(isset($_GET['mensagem']) && isset($_GET['status'])) { ?>
        <div class="alert alert-<?php echo $_GET['status']; ?> alert-dismissible show" role="alert">
          <?php echo $_GET['mensagem']; ?>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php } ?>
      </div>
    </div>


    <a href="../index.php" type="button" name="button"><img src="../assets/images/seta.png" alt="." style="height: 70px ; width: 70px"></a>


    <div class="col-12">
      <div class="row">
        <h2 class="titulocadastrados"> Usuários Cadastrados</h2>
      </div>
    </div>
    <div class="col-12">
      <?php
        $sql = "SELECT * FROM usuarios";
        $stm_sql = $db_connection->prepare($sql);
        $stm_sql->execute();
        $users = $stm_sql->fetchAll(PDO::FETCH_ASSOC);
      ?>
      <div class="table-responsive">
        <table class="table table-striped  controle">
          <thead>
            <tr>
              <th scope="col">Id:</th>
              <th scope="col">Nome:</th>
              <th scope="col">Senha:</th>
              <th scope="col">Email:</th>
              <th scope="col">Permissão:</th>
              <th scope="col">Excluir:</th>
            </tr>
          </thead>
          <tbody>
            <?php
              foreach($users as $user){
                if ($user ["permissao"]==0){
                  $permissao = "Adm";
                }else  if($user["permissao"]==1){
                  $permissao = "Comum";
                }
            ?>
              <tr>
                <th scope="row"><?php echo $user['id']; ?></td>
                <td><?php echo $user['nome'];?></td>
                <td><?php echo $user['senha'];?></td>
                <td><?php echo $user['email'];?></td>
                <td><?php echo $permissao?></td>
                <td><a href="usuariosdel.php?id=<?php echo $user['id']?>" onclick="return valDel('usuario','<?php echo $user['id'];?>')"><img src="../assets/images/excluir.png" alt="." style=" width:20px ; height:20px"><a/></td>
              </tr>
            <?php
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>


    <br>


    <div class="col-12">
      <div class="row">
        <h2 class="titulocadastrados"> Filmes Cadastrados</h2>
      </div>
    </div>
    <div class="col-12">
      <?php
        $sql = "SELECT * FROM filmes";
        $stm_sql = $db_connection->prepare($sql);
        $stm_sql->execute();
        $filmes = $stm_sql->fetchAll(PDO::FETCH_ASSOC);
      ?>
      <div class="table-responsive">
        <table class="table table-striped controle">
          <thead>
            <tr>
              <th scope="col">Id:</th>
              <th scope="col">Nome:</th>
              <th scope="col">Sinopse:</th>
              <th scope="col">Avaliação:</th>
              <th scope="col">Lançamento:</th>
              <th scope="col">Classificação:</th>
              <th scope="col">Alterar:</th>
            </tr>
          </thead>
          <tbody>
            <?php
              foreach($filmes as $filme){
            ?>
              <tr>
                <th scope="row"><?php echo $filme['id']; ?></td>
                <td><?php echo $filme['nome'];?></td>
                <td><?php echo $filme['sinopse'];?></td>
                <td><?php echo $filme['avaliacao']. " Estrelas";?></td>
                <td><?php echo $filme['lancamento'];?></td>
                <td><?php echo "Para maiores de ".$filme['classificacao']." anos";?></td>
                <td><a href="filmesfrmupd.php?id=<?php echo $filme['id'];?>"><img src="../assets/images/editar.png" alt="." style=" width:20px ; height:20px"></a></td>
              </tr>
            <?php
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>


    <br>


    <div class="col-12">
      <div class="row">
        <h2 class="titulocadastrados"> Ingressos Cadastrados</h2>
      </div>
    </div>
    <div class="col-12">
      <?php
        $sql = "SELECT * FROM ingressos";
        $stm_sql = $db_connection->prepare($sql);
        $stm_sql->execute();
        $ingressos = $stm_sql->fetchAll(PDO::FETCH_ASSOC);
      ?>
      <div class="table-responsive">
        <table class="table table-striped  controle">
          <thead>
            <tr>
              <th scope="col">Id:</th>
              <th scope="col">Filmes_Id:</th>
              <th scope="col">Usuário_Id:</th>
            </tr>
          </thead>
          <tbody>
            <?php
              foreach($ingressos as $ingresso){
            ?>
              <tr>
                <td><?php echo $ingresso['id'];?></td>
                <td><?php echo $ingresso['filmes_id'];?></td>
                <td><?php echo $ingresso['usuarios_id'];?></td>
              </tr>
            <?php
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </body>
</html>
