<?php
  $id                   = $_POST['id'];
  $nome                 = $_POST['nome'];
  $sinopse              = $_POST['sinopse'];
  $avaliacao            = $_POST['avaliacao'];
  $lancamento           = $_POST['lancamento'];
  $classificacao        = $_POST['classificacao'];
  $imagem               = $_POST['imagem'];
  $link                 = "controle.php?";
  $msg                  = "";
  $status               = "danger";

    session_start();
    if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
      header("Location:  http://localhost/teste/security/authentication/login.php");
      exit;
    }

  include "../security/database/connection.php";


  if($nome==""){
    $msg = "Preencha o campo nome corretamente no formulário de alteração.";
  }elseif($sinopse==""){
    $msg = "Preencha o campo sinopse corretamente no formulário de alteração..";
  }elseif($avaliacao==""){
    $msg = "Preencha o campo Avaliação corretamente no formulário de alteração..";
  }elseif($lancamento==""){
    $msg = "Preencha o campo Lançamento corretamente no formulário de alteração..";
  }elseif($classificacao==""){
    $msg = "Preencha o campo classificacao corretamente no formulário de alteração..";
  }else{


    $sql = "SELECT * FROM filmes WHERE nome=:nome AND id<>:id";
    $stm_sql = $db_connection->prepare($sql);
    $stm_sql->bindParam(':nome', $nome);
    $stm_sql->bindParam(':id', $id);
    $stm_sql->execute();


    if($stm_sql->rowCount()==0){
      $sql = "UPDATE filmes SET nome=:nome, sinopse=:sinopse, avaliacao=:avaliacao, lancamento=:lancamento, classificacao=:classificacao, imagem=:imagem WHERE id=:id";
      $stm_sql =$db_connection->prepare($sql);
      $stm_sql->bindParam(':id',$id);
      $stm_sql->bindParam(':nome',$nome);
      $stm_sql->bindParam(':sinopse',$sinopse);
      $stm_sql->bindParam(':avaliacao',$avaliacao);
      $stm_sql->bindParam(':lancamento',$lancamento);
      $stm_sql->bindParam(':classificacao',$classificacao);
      $stm_sql->bindParam(':imagem',$imagem);
      $result = $stm_sql->execute();


      if($result){
        $msg    = "Alteração efetuada com sucesso";
        $status = "success";
      }else{
        $msg    = "Falha ao alterar.";
        $status = "danger";
      }
    }else{
      $msg    = "Esse Filme já está cadastrado no banco de dados.";
      $status = "warning";
    }
  }
  header("Location: ".$link . "&mensagem=".$msg . "&status=".$status );
?>
