<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>CNGG</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/js/bootstrap.js">
    <link rel="stylesheet" href="../assets/css/main.css">
  </head>
  <body class="fundoinfoposter">
    <?php
      session_start();
      if((!isset($_SESSION['idsessao'])||($_SESSION['idsessao'])!=session_id())){
        header("Location:  http://localhost/teste/security/authentication/login.php");
        exit;
      }
    ?>

    <?php
      include "../security/database/connection.php";
    ?>


    <?php
      $id = $_GET['id'];
      $sql = "SELECT id, nome, sinopse, avaliacao, lancamento, classificacao, imagem FROM filmes WHERE id=:id";
      $stm_sql = $db_connection->prepare($sql);
      $stm_sql -> bindParam(':id',$id);
      $stm_sql -> execute();
      $filmes = $stm_sql -> fetch(PDO::FETCH_ASSOC);
    ?>


    <div id="quadradodaatulizacao">


      <div class="container-fluid mt-5">
        <div class="row">
          <div class="col-12">
            <?php if(isset($_GET['mensagem']) && isset($_GET['status'])) { ?>
            <div class="alert alert-<?php echo $_GET['status']; ?> alert-dismissible show" role="alert">
              <?php echo $_GET['mensagem']; ?>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>


      <div class="row h-300 justify-content-center align-items-center w-200px">
        <div class="col-md-6">
          <h2 style="color:#ff0000;">Alteração de Filme</h2>
          <form name="updcategory" action="filmesupd.php?" method="post">
            <div class="form-group">
              <input type="hidden" name="id" value="<?php echo $id;?>">
              <label>Nome do Filme:</label>
              <input type="text" class="form-control" name="nome" value="<?php echo $filmes['nome'];?>">
            </div>
            <div class="form-group">
              <label>Sinopse do Filme:</label>
              <input type="text-area" class="form-control" name="sinopse" value="<?php echo $filmes['sinopse'];?>">
            </div>
            <div class="form-group">
              <label>Avaliação do Filme:</label>
              <input type="text" class="form-control" name="avaliacao" value="<?php echo $filmes['avaliacao'];?>">
            </div>
            <div class="form-group">
              <label>Lançamento do Filme:</label>
              <input type="text" class="form-control" name="lancamento" value="<?php echo $filmes['lancamento'];?>">
            </div>
            <div class="form-group">
              <label>Classificação do Filme:</label>
              <input type="text" class="form-control" name="classificacao" value="<?php echo $filmes['classificacao'];?>">
            </div>
            <div class="form-group">
              <label>Imagem do filme</label>
              <input style="color:#ffffff;"type="file" class="form-control-file" name="imagem" value="<?php echo $filmes['imagem'];?>">
            </div>
            <a href="controle.php" type="button" name="button"><img src="../assets/images/seta.png" alt="." style="height: 70px ; width: 70px"></a>
            <button type="reset" class="btn btn-warning">Limpar</button>
            <button type="submit" class="btn btn-success">Enviar</button>
          </form>
        </div>
      </div>


    </div>
  </body>
</html>
